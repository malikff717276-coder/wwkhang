<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

session_name(SESSION_NAME);
session_start();

function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    static $cached = null;
    if ($cached !== null) return $cached;

    $stmt = get_db()->prepare('SELECT id, username, email, tokens, is_admin FROM users WHERE id = ? AND is_active = 1');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if (!$user) {
        session_destroy();
        return null;
    }
    return $cached = $user;
}

function require_login(): array {
    $user = current_user();
    if (!$user) {
        header('Location: login.php');
        exit;
    }
    return $user;
}

function require_admin(): array {
    $user = require_login();
    if (!$user['is_admin']) {
        http_response_code(403);
        die('Admin access only.');
    }
    return $user;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_check(): void {
    if (empty($_POST['csrf']) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
        http_response_code(403);
        die('Invalid request (CSRF check failed). Please refresh and try again.');
    }
}

// For AJAX endpoints that send JSON bodies (e.g. send.php), where the
// token isn't in $_POST. Pass the token you pulled out of the decoded
// JSON body yourself.
function csrf_check_json(?string $token): void {
    if (empty($token) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Invalid request (CSRF check failed). Please refresh and try again.']);
        exit;
    }
}

// Very lightweight per-session flood guard. Not a substitute for the
// worker-side auth (see note in send.php) but stops a compromised
// browser session / runaway script from hammering the AI backend
// faster than a human could type, which is what actually burns your
// Cloudflare + Gemini usage.
function flood_check(float $minIntervalSeconds = 1.5): void {
    $now = microtime(true);
    if (!empty($_SESSION['last_msg_at']) && ($now - $_SESSION['last_msg_at']) < $minIntervalSeconds) {
        http_response_code(429);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Sending too fast — please wait a moment.']);
        exit;
    }
    $_SESSION['last_msg_at'] = $now;
}

function adjust_tokens(int $userId, int $amount, string $reason): void {
    $db = get_db();
    $db->beginTransaction();
    try {
        $stmt = $db->prepare('UPDATE users SET tokens = tokens + ? WHERE id = ?');
        $stmt->execute([$amount, $userId]);

        $stmt = $db->prepare('INSERT INTO token_log (user_id, change_amt, reason) VALUES (?, ?, ?)');
        $stmt->execute([$userId, $amount, $reason]);

        $db->commit();
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}
