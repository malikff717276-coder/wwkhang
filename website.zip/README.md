# Setup on InfinityFree

1. **Database**: In your InfinityFree control panel, create a MySQL database. Copy the host/dbname/user/password into `config.php`.
2. **Import schema**: Open phpMyAdmin (linked from InfinityFree panel) → your database → SQL tab → paste the contents of `schema.sql` → Go.
3. **Worker URL + secret** (see `worker/` folder for the patched Main Worker):
   - Deploy `worker/main-worker.js` as your Main Router Worker (or merge the auth block into your existing deployment — see "Worker auth" below).
   - In `config.php`, set `WORKER_URL` to that worker's own `*.workers.dev` URL — **not** one of the receiver URLs (Account #2–#5).
   - Set the same secret on both sides:
     - Worker side: `wrangler secret put WEBSITE_SECRET` (paste a long random value).
     - Website side: set `WORKER_SECRET` — as an env var if your host supports it, otherwise hardcode it directly in `config.php` (it's safe there: PHP files execute server-side, they're never served as text, as long as you don't rename it to `.txt`).
4. **Upload files**: Upload everything (`config.php`, `db.php`, `auth.php`, `signup.php`, `login.php`, `logout.php`, `chat.php`, `send.php`, `new_chat.php`, `admin.php`, `assets/`) to `htdocs/` via FTP or the File Manager. Don't upload the `worker/` folder — that's deployed to Cloudflare separately, not to InfinityFree.
5. **Create your admin account**: Sign up normally through the site once it's live, then in phpMyAdmin run:
   ```sql
   UPDATE users SET is_admin = 1 WHERE username = 'yourusername';
   ```
6. **Test end-to-end**: Sign up → land on `chat.php` with `SIGNUP_BONUS_TOKENS` tokens → send a message → hits your Main Worker → deducts a token → reply appears.

## Worker auth (important — closes a real gap)

The Main Worker had no check on who's calling it: anyone who found its URL could `curl`/Postman it directly, with no tokens deducted and no relation to your website at all — burning every downstream Cloudflare account plus your Gemini key for free.

`worker/main-worker.js` in this zip is your worker with one block added, right after the `OPTIONS`/method check: it requires `Authorization: Bearer <WEBSITE_SECRET>` on every request and rejects anything else with `401`. `send.php` already sends that header — nothing to change on the PHP side, just deploy the patched worker and set `WEBSITE_SECRET` to match `WORKER_SECRET` in `config.php`.

If you've made other edits to the worker since the version you shared, don't overwrite it wholesale — copy just the auth block (the section between `// AUTH —` and the `try {`) plus the `timingSafeEqual` helper into your current file.

## What's built so far
- Public signup / login / logout with hashed passwords, CSRF protection, sessions
- Token balance per user, auto-deduct per message, auto-refund if the AI call fails
- Multiple conversations per user — sidebar list, "New chat" creates a real row, switching conversations switches which Worker KV memory thread is used (`{user_id}_conv{conversation_id}`)
- ChatGPT-style dark chat UI, full history stored in MySQL
- Admin panel: view all users, top up tokens, enable/disable accounts, promote/demote admins
- Site name controlled from one place (`config.php` → `SITE_NAME`)
- Worker-side auth so only your website can call the Main Worker (see above)

## Not built yet — next steps to discuss
- **Image attachments** — needs file upload handling on the website + deciding how the image gets to Moondream (Account #4). The worker already accepts an `attachments[]` array and routes vision requests to `moondream`, so this is mostly frontend + send.php work now.
- **Payment integration** for buying tokens (right now only admin can top up manually).
- **Rate limiting / abuse protection** beyond the per-session flood guard + token system.

Bata do pehle kis pe focus karna hai — image upload ya payment/token-purchase flow.
