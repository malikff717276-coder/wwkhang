<?php
require_once __DIR__ . '/auth.php';

if (current_user()) {
    header('Location: chat.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
        $error = 'Username must be 3-30 characters (letters, numbers, underscore only).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } else {
        $db = get_db();
        $stmt = $db->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $error = 'That username or email is already taken.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare('INSERT INTO users (username, email, password_hash, tokens) VALUES (?, ?, ?, ?)');
            $stmt->execute([$username, $email, $hash, SIGNUP_BONUS_TOKENS]);
            $userId = (int)$db->lastInsertId();

            $stmt = $db->prepare('INSERT INTO token_log (user_id, change_amt, reason) VALUES (?, ?, ?)');
            $stmt->execute([$userId, SIGNUP_BONUS_TOKENS, 'signup_bonus']);

            $_SESSION['user_id'] = $userId;
            header('Location: chat.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Sign up — <?= htmlspecialchars(SITE_NAME) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth-page">
  <div class="auth-card">
    <h1><?= htmlspecialchars(SITE_NAME) ?></h1>
    <p class="tagline"><?= htmlspecialchars(SITE_TAGLINE) ?></p>

    <?php if ($error): ?>
      <div class="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" class="auth-form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <label>Username
        <input type="text" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
      </label>
      <label>Email
        <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </label>
      <label>Password
        <input type="password" name="password" minlength="8" required>
      </label>
      <button type="submit">Create account</button>
    </form>

    <p class="switch">Already have an account? <a href="login.php">Log in</a></p>
  </div>
</body>
</html>
