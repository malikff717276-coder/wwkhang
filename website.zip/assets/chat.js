(function () {
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');
  const sendBtn = document.getElementById('sendBtn');
  const messages = document.getElementById('messages');
  const tokenCount = document.getElementById('tokenCount');

  // Auto-grow the textarea
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 160) + 'px';
  });

  // Enter to send, Shift+Enter for newline
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  function addBubble(role, text) {
    const empty = messages.querySelector('.empty-state');
    if (empty) empty.remove();

    const row = document.createElement('div');
    row.className = 'msg msg-' + role;
    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';
    bubble.textContent = text;
    row.appendChild(bubble);
    messages.appendChild(row);
    messages.scrollTop = messages.scrollHeight;
    return bubble;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;

    addBubble('user', text);
    input.value = '';
    input.style.height = 'auto';
    sendBtn.disabled = true;

    const thinkingBubble = addBubble('assistant', 'Thinking…');

    try {
      const res = await fetch('send.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation_id: window.CONV_ID,
          message: text,
          csrf: window.CSRF,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        thinkingBubble.textContent = data.error || 'Something went wrong.';
        return;
      }

      thinkingBubble.textContent = data.reply;
      if (typeof data.tokens === 'number') {
        tokenCount.textContent = data.tokens;
      }
    } catch (err) {
      thinkingBubble.textContent = 'Network error — please try again.';
    } finally {
      sendBtn.disabled = false;
      input.focus();
    }
  });
})();
