<?php
require_once __DIR__ . '/auth.php';
$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}
csrf_check();

$db = get_db();
$db->prepare('INSERT INTO conversations (user_id, title) VALUES (?, ?)')
   ->execute([$user['id'], 'New chat']);
$newId = (int)$db->lastInsertId();

header('Location: chat.php?conv=' . $newId);
exit;
