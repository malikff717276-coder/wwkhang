/*
  MAIN AI ROUTER WORKER

  Architecture:

  Website
      ↓
  Main Worker
      ↓
  Gemini Router
      ↓
  ┌─────────────────────────────────────┐
  │ Qwen3.8 27B → Main Account          │
  │ Qwen3 30B  → Account #2 Receiver    │
  │ Coder32B   → Account #3 Receiver     │
  │ Moondream  → Account #4 Receiver    │
  │ GLM4.7     → Account #5 Receiver     │
  └─────────────────────────────────────┘
      ↓
  Main Worker
      ↓
  Website

  KV:
  chat:<userId>
*/


const MODELS = {
  qwen38: "@cf/qwen/qwen3.8-27b",
  qwen30b: "@cf/qwen/qwen3-30b-a3b-fp8",
  coder32b: "@cf/qwen/qwen2.5-coder-32b-instruct",
  moondream: "@cf/moondream/moondream3.1-9B-A2B",
  glm47: "@cf/zai-org/glm-4.7-flash",
};


// Remote receiver Workers
const RECEIVERS = {
  qwen30b:
    "https://spring-resonance-2e84.algebaric0960.workers.dev/",

  coder32b:
    "https://jolly-shape-29b3.touseefuuii88.workers.dev/",

  moondream:
    "https://flat-king-b1cf.sadiatariqghzali.workers.dev/",

  glm47:
    "https://lucky-recipe-8357.fastsgamer95.workers.dev/",
};


// Gemini router model
const ROUTER_MODEL = "gemini-3.7-flash";


// Maximum chat history stored in KV
const MAX_HISTORY_MESSAGES = 30;


// Maximum size of individual text messages
const MAX_MESSAGE_CHARS = 30000;


// Allowed route names
const VALID_ROUTES = new Set([
  "qwen38",
  "qwen30b",
  "coder32b",
  "moondream",
  "glm47",
]);


/* =========================================================
   MAIN FETCH
========================================================= */

export default {
  async fetch(request, env, ctx) {

    const origin = request.headers.get("Origin");

    // -----------------------------------------------------
    // CORS
    // -----------------------------------------------------

    const corsHeaders = getCorsHeaders(origin);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders,
      });
    }


    // -----------------------------------------------------
    // Only POST allowed
    // -----------------------------------------------------

    if (request.method !== "POST") {
      return jsonResponse(
        {
          success: false,
          error: "Method not allowed",
        },
        405,
        corsHeaders
      );
    }


    // -----------------------------------------------------
    // AUTH — only our own website (send.php) may call this
    // worker. Without this, anyone who finds this URL can
    // hit it directly with curl/Postman and burn every
    // downstream account's usage for free, with no tokens
    // deducted anywhere.
    //
    // send.php already sends: Authorization: Bearer <secret>
    // Set the same value as a Worker secret:
    //   wrangler secret put WEBSITE_SECRET
    // -----------------------------------------------------

    if (!env.WEBSITE_SECRET) {
      return jsonResponse(
        {
          success: false,
          error: "Server misconfigured: WEBSITE_SECRET not set",
        },
        500,
        corsHeaders
      );
    }

    const authHeader = request.headers.get("Authorization") || "";
    const providedSecret = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7).trim()
      : "";

    if (
      !providedSecret ||
      !timingSafeEqual(providedSecret, env.WEBSITE_SECRET)
    ) {
      return jsonResponse(
        {
          success: false,
          error: "Unauthorized",
        },
        401,
        corsHeaders
      );
    }


    try {

      // ---------------------------------------------------
      // Parse request body
      // ---------------------------------------------------

      const body = await request.json();


      // ---------------------------------------------------
      // User/session ID
      // ---------------------------------------------------

      const userId = getUserId(request, body);


      // ---------------------------------------------------
      // User message
      // ---------------------------------------------------

      const message = normalizeMessage(
        body.message ?? body.prompt ?? ""
      );


      if (!message && !Array.isArray(body.attachments)) {
        return jsonResponse(
          {
            success: false,
            error: "Message is required",
          },
          400,
          corsHeaders
        );
      }


      // ---------------------------------------------------
      // Attachments
      // ---------------------------------------------------

      const attachments = normalizeAttachments(
        body.attachments
      );


      // ---------------------------------------------------
      // Detect request type
      // ---------------------------------------------------

      const requestInfo = detectRequestType(
        message,
        attachments
      );


      // ---------------------------------------------------
      // Load user's private KV memory
      // ---------------------------------------------------

      const kvKey = `chat:${userId}`;

      let storedChat = await env.CHAT_MEMORY.get(
        kvKey,
        "json"
      );


      if (!storedChat || typeof storedChat !== "object") {
        storedChat = {
          userId,
          messages: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
      }


      // ---------------------------------------------------
      // Sanitize old history
      // ---------------------------------------------------

      const history = sanitizeHistory(
        storedChat.messages
      );


      // ---------------------------------------------------
      // Build current conversation
      // ---------------------------------------------------

      const conversationForRouter = [
        ...history,
        {
          role: "user",
          content: message || "[Attachment only request]",
        },
      ];


      // ---------------------------------------------------
      // Gemini decides which model should handle request
      // ---------------------------------------------------

      let routing;

      try {

        routing = await classifyWithGemini(
          env,
          {
            message,
            history: conversationForRouter,
            requestInfo,
            attachments,
          }
        );

      } catch (routerError) {

        console.error(
          "Gemini router failed:",
          routerError
        );

        routing = fallbackRouting(
          requestInfo
        );
      }


      // ---------------------------------------------------
      // Guarantee safe model selection
      // ---------------------------------------------------

      const selectedModel = normalizeRoute(
        routing?.recommended_model,
        requestInfo
      );


      // ---------------------------------------------------
      // Add extracted document text if frontend provides it
      // ---------------------------------------------------

      let finalUserMessage = message;

      const documentText = extractDocumentText(
        attachments
      );


      if (documentText) {

        finalUserMessage +=
          "\n\n[DOCUMENT CONTENT]\n" +
          documentText +
          "\n[END DOCUMENT CONTENT]";
      }


      // ---------------------------------------------------
      // Build model messages
      // ---------------------------------------------------

      const modelMessages = buildModelMessages(
        history,
        finalUserMessage,
        attachments,
        selectedModel
      );


      // ---------------------------------------------------
      // Run selected model
      // ---------------------------------------------------

      const modelResult = await dispatchModel(
        env,
        selectedModel,
        {
          userId,
          message: finalUserMessage,
          messages: modelMessages,
          attachments,
          requestInfo,
        }
      );


      // ---------------------------------------------------
      // Extract final assistant text
      // ---------------------------------------------------

      const assistantText = extractAssistantText(
        modelResult
      );


      if (!assistantText) {

        throw new Error(
          "Selected model returned an empty response"
        );
      }


      // ---------------------------------------------------
      // Save ONLY actual conversation to KV
      //
      // Gemini routing information is NOT saved as
      // visible conversation memory.
      // ---------------------------------------------------

      const updatedMessages = [
        ...history,
        {
          role: "user",
          content: message || "[Attachment only request]",
          timestamp: new Date().toISOString(),
        },
        {
          role: "assistant",
          content: assistantText,
          model: selectedModel,
          timestamp: new Date().toISOString(),
        },
      ].slice(-MAX_HISTORY_MESSAGES);


      const newChatState = {
        userId,
        messages: updatedMessages,
        createdAt:
          storedChat.createdAt ||
          new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };


      ctx.waitUntil(
        env.CHAT_MEMORY.put(
          kvKey,
          JSON.stringify(newChatState)
        )
      );


      // ---------------------------------------------------
      // Final response
      // ---------------------------------------------------

      return jsonResponse(
        {
          success: true,

          userId,

          response: assistantText,

          routing: {
            task: routing?.task || requestInfo.task,
            complexity:
              routing?.complexity ||
              requestInfo.complexity,

            vision:
              Boolean(routing?.vision) ||
              requestInfo.hasImage,

            document:
              Boolean(routing?.document) ||
              requestInfo.hasDocument,

            model: selectedModel,
          },

          model: selectedModel,

          // Useful later for live frontend
          conversation: {
            messagesStored: updatedMessages.length,
          },
        },
        200,
        corsHeaders
      );


    } catch (error) {

      console.error(
        "MAIN WORKER ERROR:",
        error
      );


      return jsonResponse(
        {
          success: false,
          error: "Internal server error",
          message:
            error?.message ||
            "Unknown error",
        },
        500,
        corsHeaders
      );
    }
  },
};


/* =========================================================
   CORS
========================================================= */

function getCorsHeaders(origin) {

  /*
    Lock this down once your site is live: replace with your
    exact website origin (e.g. "https://yoursite.rf.gd"),
    since the request is now authenticated with a shared
    secret anyway, but a fixed origin is one more layer.
  */

  const allowedOrigin =
    origin || "*";


  return {
    "Access-Control-Allow-Origin":
      allowedOrigin,

    "Access-Control-Allow-Methods":
      "POST, OPTIONS",

    "Access-Control-Allow-Headers":
      "Content-Type, Authorization, X-User-ID",

    "Access-Control-Allow-Credentials":
      "true",

    "Access-Control-Max-Age":
      "86400",
  };
}


/* =========================================================
   TIMING-SAFE STRING COMPARE (for the shared secret)
========================================================= */

function timingSafeEqual(a, b) {

  const enc = new TextEncoder();
  const bufA = enc.encode(a);
  const bufB = enc.encode(b);

  if (bufA.length !== bufB.length) {
    // Still compare against something of equal length to
    // avoid leaking length via timing on top of content.
    return false;
  }

  let diff = 0;
  for (let i = 0; i < bufA.length; i++) {
    diff |= bufA[i] ^ bufB[i];
  }

  return diff === 0;
}


/* =========================================================
   JSON RESPONSE
========================================================= */

function jsonResponse(data, status, corsHeaders) {

  return new Response(
    JSON.stringify(data),
    {
      status,

      headers: {
        "Content-Type":
          "application/json; charset=utf-8",

        ...corsHeaders,
      },
    }
  );
}


/* =========================================================
   USER ID
========================================================= */

function getUserId(request, body) {

  // Priority 1: Header
  const headerId =
    request.headers.get("X-User-ID");

  if (headerId) {
    return sanitizeUserId(headerId);
  }


  // Priority 2: JSON body
  if (body?.userId) {
    return sanitizeUserId(body.userId);
  }


  // Priority 3: Cookie
  const cookieId =
    getCookie(request.headers.get("Cookie"), "userId");

  if (cookieId) {
    return sanitizeUserId(cookieId);
  }


  // Priority 4: Generate browser/session ID
  return crypto.randomUUID();
}


function sanitizeUserId(value) {

  const clean = String(value)
    .trim()
    .replace(/[^a-zA-Z0-9._:-]/g, "")
    .slice(0, 128);


  return clean || crypto.randomUUID();
}


function getCookie(cookieHeader, name) {

  if (!cookieHeader) {
    return null;
  }


  const cookies =
    cookieHeader.split(";");


  for (const cookie of cookies) {

    const [key, ...rest] =
      cookie.trim().split("=");


    if (key === name) {

      return decodeURIComponent(
        rest.join("=")
      );
    }
  }


  return null;
}


/* =========================================================
   MESSAGE NORMALIZATION
========================================================= */

function normalizeMessage(value) {

  if (value === null || value === undefined) {
    return "";
  }


  return String(value)
    .trim()
    .slice(0, MAX_MESSAGE_CHARS);
}


/* =========================================================
   ATTACHMENT NORMALIZATION
========================================================= */

function normalizeAttachments(attachments) {

  if (!Array.isArray(attachments)) {
    return [];
  }


  return attachments
    .slice(0, 10)
    .map((file) => {

      if (!file || typeof file !== "object") {
        return null;
      }


      return {
        type:
          typeof file.type === "string"
            ? file.type.slice(0, 100)
            : "unknown",

        name:
          typeof file.name === "string"
            ? file.name.slice(0, 255)
            : "attachment",

        mimeType:
          typeof file.mimeType === "string"
            ? file.mimeType.slice(0, 150)
            : "",

        url:
          typeof file.url === "string"
            ? file.url.slice(0, 2000)
            : null,

        data:
          typeof file.data === "string"
            ? file.data
            : null,

        text:
          typeof file.text === "string"
            ? file.text.slice(0, 100000)
            : null,
      };
    })
    .filter(Boolean);
}


/* =========================================================
   REQUEST TYPE DETECTION
========================================================= */

function detectRequestType(
  message,
  attachments
) {

  const lower =
    message.toLowerCase();


  const hasImage =
    attachments.some((a) =>
      isImageAttachment(a)
    );


  const hasDocument =
    attachments.some((a) =>
      isDocumentAttachment(a)
    );


  let task = "general";
  let complexity = "normal";


  // Coding
  if (
    /\b(code|coding|program|programming|javascript|typescript|python|php|html|css|sql|bug|debug|api|function|class|regex|cloudflare|worker)\b/i.test(
      lower
    )
  ) {

    task = "coding";
  }


  // Reasoning
  if (
    /\b(prove|derive|analyze|analyse|reason|solve|why|compare|architecture|complex|deep|step by step)\b/i.test(
      lower
    )
  ) {

    task = "reasoning";
    complexity = "complex";
  }


  // Document
  if (hasDocument) {

    task = "document";
  }


  // Vision
  if (hasImage) {

    task = "vision";
  }


  return {
    task,
    complexity,
    hasImage,
    hasDocument,
  };
}


/* =========================================================
   GEMINI ROUTER
========================================================= */

async function classifyWithGemini(
  env,
  {
    message,
    history,
    requestInfo,
    attachments,
  }
) {

  if (!env.GEMINI_API_KEY) {
    throw new Error(
      "GEMINI_API_KEY is missing"
    );
  }


  const routerPrompt = `
You are the routing classifier for a multi-model AI system.

Your ONLY job is to decide which model should handle the
user's ORIGINAL request.

Available models:

qwen38:
General purpose, complex reasoning, advanced tasks,
multimodal reasoning, difficult requests.

qwen30b:
General conversation, normal questions, explanations,
casual requests and everyday tasks.

coder32b:
Programming, debugging, code generation, software
engineering, APIs and technical coding tasks.

moondream:
Image understanding, image questions, object detection,
captioning, OCR and visual analysis.

glm47:
General purpose, multilingual, reasoning, coding and
normal complex requests.

Rules:

1. If image understanding is the primary task, choose moondream.
2. If the request is coding/programming, choose coder32b.
3. If difficult reasoning is required, choose qwen38.
4. If the request is simple/general/casual, choose qwen30b.
5. GLM47 can handle general, multilingual or reasoning tasks
   when appropriate.
6. If a request contains an image AND requires very complex
   reasoning, qwen38 may be selected.
7. Documents should be handled as document tasks. If the
   document is primarily visual/image based, moondream may
   be selected.
8. Greetings and casual conversation should NOT be sent to
   coding or vision models.
9. Do not rewrite or answer the user request.
10. Return ONLY the routing JSON.

User request:

${message || "[attachment only request]"}

Detected information:

${JSON.stringify(requestInfo)}

Recent conversation:

${JSON.stringify(history.slice(-8))}

Attachments:

${JSON.stringify(
  attachments.map((a) => ({
    type: a.type,
    name: a.name,
    mimeType: a.mimeType,
    hasData: Boolean(a.data),
    hasText: Boolean(a.text),
    hasUrl: Boolean(a.url),
  }))
)}

Return JSON with exactly these fields:

{
  "task": "greeting|general|coding|reasoning|vision|document|mixed",
  "complexity": "simple|normal|complex",
  "vision": true,
  "document": false,
  "recommended_model": "qwen38|qwen30b|coder32b|moondream|glm47"
}
`;


  const endpoint =
    `https://generativelanguage.googleapis.com/v1beta/models/${ROUTER_MODEL}:generateContent?key=${encodeURIComponent(
      env.GEMINI_API_KEY
    )}`;


  const response =
    await fetch(endpoint, {

      method: "POST",

      headers: {
        "Content-Type":
          "application/json",
      },

      body: JSON.stringify({

        contents: [
          {
            role: "user",
            parts: [
              {
                text: routerPrompt,
              },
            ],
          },
        ],

        generationConfig: {

          temperature: 0,

          responseMimeType:
            "application/json",

          responseSchema: {

            type: "OBJECT",

            properties: {

              task: {
                type: "STRING",
              },

              complexity: {
                type: "STRING",
              },

              vision: {
                type: "BOOLEAN",
              },

              document: {
                type: "BOOLEAN",
              },

              recommended_model: {
                type: "STRING",
              },
            },

            required: [
              "task",
              "complexity",
              "vision",
              "document",
              "recommended_model",
            ],
          },
        },
      }),
    });


  if (!response.ok) {

    const errorText =
      await response.text();

    throw new Error(
      `Gemini router HTTP ${response.status}: ${errorText}`
    );
  }


  const data =
    await response.json();


  const rawText =
    data?.candidates?.[0]?.content?.parts
      ?.map((part) => part?.text || "")
      .join("")
      .trim();


  if (!rawText) {

    throw new Error(
      "Gemini returned empty routing response"
    );
  }


  return safeJsonParse(rawText);
}


/* =========================================================
   SAFE JSON PARSER
========================================================= */

function safeJsonParse(text) {

  try {
    return JSON.parse(text);
  } catch (_) {
    // Try extracting the first JSON object
  }


  const start =
    text.indexOf("{");

  const end =
    text.lastIndexOf("}");


  if (
    start !== -1 &&
    end !== -1 &&
    end > start
  ) {

    const candidate =
      text.slice(start, end + 1);

    return JSON.parse(candidate);
  }


  throw new Error(
    "Could not parse Gemini routing JSON"
  );
}


/* =========================================================
   FALLBACK ROUTING
========================================================= */

function fallbackRouting(
  requestInfo
) {

  if (requestInfo.hasImage) {

    return {
      task: "vision",
      complexity: "normal",
      vision: true,
      document: false,
      recommended_model: "moondream",
    };
  }


  if (requestInfo.hasDocument) {

    return {
      task: "document",
      complexity: "normal",
      vision: false,
      document: true,
      recommended_model: "qwen38",
    };
  }


  if (requestInfo.task === "coding") {

    return {
      task: "coding",
      complexity: "normal",
      vision: false,
      document: false,
      recommended_model: "coder32b",
    };
  }


  if (requestInfo.complexity === "complex") {

    return {
      task: "reasoning",
      complexity: "complex",
      vision: false,
      document: false,
      recommended_model: "qwen38",
    };
  }


  return {
    task: "general",
    complexity: "normal",
    vision: false,
    document: false,
    recommended_model: "qwen30b",
  };
}


/* =========================================================
   ROUTE NORMALIZATION
========================================================= */

function normalizeRoute(
  route,
  requestInfo
) {

  if (
    typeof route === "string" &&
    VALID_ROUTES.has(route)
  ) {

    // Hard safety rules

    if (
      requestInfo.hasImage &&
      requestInfo.task === "vision"
    ) {

      return "moondream";
    }


    if (
      requestInfo.task === "coding"
    ) {

      return "coder32b";
    }


    return route;
  }


  return fallbackRouting(
    requestInfo
  ).recommended_model;
}


/* =========================================================
   MODEL MESSAGE BUILDER
========================================================= */

function buildModelMessages(
  history,
  currentMessage,
  attachments,
  selectedModel
) {

  const messages = [];


  // Keep previous conversation
  for (const item of history) {

    if (
      item.role !== "user" &&
      item.role !== "assistant"
    ) {
      continue;
    }


    messages.push({
      role: item.role,
      content: item.content,
    });
  }


  // -------------------------------------------------------
  // Current message
  // -------------------------------------------------------

  const imageAttachments =
    attachments.filter(
      isImageAttachment
    );


  /*
    Qwen3.8 supports multimodal messages.

    For normal text requests, simple string content is used.

    For image requests, OpenAI-style content parts are used.
  */

  if (
    selectedModel === "qwen38" &&
    imageAttachments.length > 0
  ) {

    const content = [];


    content.push({
      type: "text",
      text:
        currentMessage ||
        "Please analyze the attached image.",
    });


    for (const image of imageAttachments) {

      const imageUrl =
        image.url ||
        image.data;


      if (!imageUrl) {
        continue;
      }


      content.push({
        type: "image_url",
        image_url: {
          url: imageUrl,
        },
      });
    }


    messages.push({
      role: "user",
      content,
    });


  } else {

    messages.push({
      role: "user",
      content:
        currentMessage ||
        "[Attachment only request]",
    });
  }


  return messages;
}


/* =========================================================
   MODEL DISPATCHER
========================================================= */

async function dispatchModel(
  env,
  model,
  payload
) {

  switch (model) {

    case "qwen38":

      return await runQwen38(
        env,
        payload
      );


    case "qwen30b":

      return await runRemoteReceiver(
        RECEIVERS.qwen30b,
        env.ACCOUNT2_QWEN30B_SECRET,
        payload,
        "qwen30b"
      );


    case "coder32b":

      return await runRemoteReceiver(
        RECEIVERS.coder32b,
        env.ACCOUNT3_CODER32B_SECRET,
        payload,
        "coder32b"
      );


    case "moondream":

      return await runRemoteReceiver(
        RECEIVERS.moondream,
        env.ACCOUNT4_MOONDREAM_SECRET,
        payload,
        "moondream"
      );


    case "glm47":

      return await runRemoteReceiver(
        RECEIVERS.glm47,
        env.ACCOUNT5_GLM47_SECRET,
        payload,
        "glm47"
      );


    default:

      throw new Error(
        `Unknown model route: ${model}`
      );
  }
}


/* =========================================================
   MAIN ACCOUNT — QWEN3.8
========================================================= */

async function runQwen38(
  env,
  {
    userId,
    messages,
  }
) {

  if (!env.AI) {

    throw new Error(
      "Workers AI binding AI is missing"
    );
  }


  const result =
    await env.AI.run(
      MODELS.qwen38,
      {
        messages,

        user: userId,

        max_completion_tokens: 4096,

        temperature: 0.7,

        stream: false,
      }
    );


  return result;
}


/* =========================================================
   REMOTE RECEIVER
========================================================= */

async function runRemoteReceiver(
  receiverUrl,
  secret,
  {
    userId,
    message,
    messages,
    attachments,
    requestInfo,
  },
  modelName
) {

  if (!receiverUrl) {

    throw new Error(
      `${modelName} receiver URL is missing`
    );
  }


  if (!secret) {

    throw new Error(
      `${modelName} receiver secret is missing`
    );
  }


  const response =
    await fetch(
      receiverUrl,
      {

        method: "POST",

        headers: {

          "Content-Type":
            "application/json",

          "Authorization":
            `Bearer ${secret}`,
        },

        body: JSON.stringify({

          userId,

          model:
            modelName === "qwen30b"
              ? MODELS.qwen30b
              : modelName === "coder32b"
              ? MODELS.coder32b
              : modelName === "moondream"
              ? MODELS.moondream
              : MODELS.glm47,

          messages,

          message,

          attachments,

          vision:
            requestInfo.hasImage,

          document:
            requestInfo.hasDocument,

          task:
            requestInfo.task,
        }),
      }
    );


  if (!response.ok) {

    const errorText =
      await response.text();

    throw new Error(
      `${modelName} receiver HTTP ${response.status}: ${errorText}`
    );
  }


  const contentType =
    response.headers.get(
      "content-type"
    ) || "";


  if (
    contentType.includes(
      "application/json"
    )
  ) {

    return await response.json();
  }


  return {
    response:
      await response.text(),
  };
}


/* =========================================================
   ASSISTANT RESPONSE EXTRACTION
========================================================= */

function extractAssistantText(result) {

  if (result === null || result === undefined) {
    return "";
  }


  if (typeof result === "string") {
    return result.trim();
  }


  // Common Workers AI response
  if (
    typeof result.response === "string"
  ) {

    return result.response.trim();
  }


  // OpenAI-style response
  if (
    result.choices?.[0]?.message?.content
  ) {

    const content =
      result.choices[0].message.content;


    if (typeof content === "string") {
      return content.trim();
    }


    if (Array.isArray(content)) {

      return content
        .map((part) =>
          typeof part === "string"
            ? part
            : part?.text || ""
        )
        .join("")
        .trim();
    }
  }


  // Some model responses
  if (
    typeof result.answer === "string"
  ) {

    return result.answer.trim();
  }


  // Moondream can return caption/answer
  if (
    typeof result.caption === "string"
  ) {

    return result.caption.trim();
  }


  if (
    typeof result.result?.response === "string"
  ) {

    return result.result.response.trim();
  }


  if (
    typeof result.result?.answer === "string"
  ) {

    return result.result.answer.trim();
  }


  return "";
}


/* =========================================================
   DOCUMENT TEXT EXTRACTION
========================================================= */

function extractDocumentText(
  attachments
) {

  const texts = [];


  for (const attachment of attachments) {

    if (
      isDocumentAttachment(attachment) &&
      attachment.text
    ) {

      texts.push(
        `File: ${attachment.name}\n${attachment.text}`
      );
    }
  }


  if (!texts.length) {
    return "";
  }


  return texts.join(
    "\n\n--------------------\n\n"
  );
}


/* =========================================================
   ATTACHMENT HELPERS
========================================================= */

function isImageAttachment(
  attachment
) {

  const mime =
    attachment?.mimeType ||
    attachment?.type ||
    "";


  return (
    mime.startsWith("image/") ||
    attachment?.type === "image"
  );
}


function isDocumentAttachment(
  attachment
) {

  const mime =
    attachment?.mimeType ||
    attachment?.type ||
    "";


  return (
    mime.includes("pdf") ||
    mime.includes("document") ||
    mime.includes("text/") ||
    mime.includes("spreadsheet") ||
    mime.includes("word") ||
    attachment?.type === "document" ||
    attachment?.type === "pdf"
  );
}


/* =========================================================
   HISTORY SANITIZATION
========================================================= */

function sanitizeHistory(
  messages
) {

  if (!Array.isArray(messages)) {
    return [];
  }


  return messages
    .filter(
      (message) =>
        message &&
        (
          message.role === "user" ||
          message.role === "assistant"
        ) &&
        typeof message.content === "string"
    )
    .slice(-MAX_HISTORY_MESSAGES)
    .map((message) => ({

      role: message.role,

      content:
        message.content
          .slice(0, MAX_MESSAGE_CHARS),
    }));
}
