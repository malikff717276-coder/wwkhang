<?php
require_once __DIR__ . '/auth.php';

// Entry point: logged-in users go straight to chat, everyone else to login.
if (current_user()) {
    header('Location: chat.php');
} else {
    header('Location: login.php');
}
exit;
