<?php
require_once __DIR__ . '/auth.php';
$user = require_login();
$db = get_db();

// If a specific conversation was requested, load it — but only if it
// actually belongs to this user (prevents id-guessing to read someone
// else's chat).
$conv = null;
$requestedId = (int)($_GET['conv'] ?? 0);
if ($requestedId) {
    $stmt = $db->prepare('SELECT id, title FROM conversations WHERE id = ? AND user_id = ?');
    $stmt->execute([$requestedId, $user['id']]);
    $conv = $stmt->fetch();
}

// Otherwise fall back to the most recent conversation
if (!$conv) {
    $stmt = $db->prepare('SELECT id, title FROM conversations WHERE user_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$user['id']]);
    $conv = $stmt->fetch();
}

if (!$conv) {
    $db->prepare('INSERT INTO conversations (user_id, title) VALUES (?, ?)')->execute([$user['id'], 'New chat']);
    $convId = (int)$db->lastInsertId();
} else {
    $convId = (int)$conv['id'];
}

$stmt = $db->prepare('SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY id ASC');
$stmt->execute([$convId]);
$history = $stmt->fetchAll();

// This user's conversations for the sidebar switcher
$stmt = $db->prepare('SELECT id, title FROM conversations WHERE user_id = ? ORDER BY id DESC LIMIT 30');
$stmt->execute([$user['id']]);
$allConvs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars(SITE_NAME) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="chat-page">
  <div class="app-shell">
    <aside class="sidebar">
      <div class="brand"><?= htmlspecialchars(SITE_NAME) ?></div>

      <form method="post" action="new_chat.php">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
        <button type="submit" class="new-chat">+ New chat</button>
      </form>

      <nav class="conv-list">
        <?php foreach ($allConvs as $c): ?>
          <a class="conv-item<?= (int)$c['id'] === $convId ? ' active' : '' ?>"
             href="chat.php?conv=<?= (int)$c['id'] ?>">
            <?= htmlspecialchars($c['title']) ?>
          </a>
        <?php endforeach; ?>
      </nav>

      <div class="sidebar-spacer"></div>
      <div class="token-badge">Tokens: <span id="tokenCount"><?= (int)$user['tokens'] ?></span></div>
      <div class="sidebar-links">
        <?php if ($user['is_admin']): ?>
          <a href="admin.php">Admin panel</a>
        <?php endif; ?>
        <a href="logout.php">Log out (<?= htmlspecialchars($user['username']) ?>)</a>
      </div>
    </aside>

    <main class="chat-main">
      <div class="messages" id="messages">
        <?php if (!$history): ?>
          <div class="empty-state">
            <h2>What are you working on?</h2>
            <p>Describe your problem or attach a screenshot — I'll help you solve it.</p>
          </div>
        <?php endif; ?>
        <?php foreach ($history as $m): ?>
          <div class="msg msg-<?= $m['role'] ?>">
            <div class="msg-bubble"><?= nl2br(htmlspecialchars($m['content'])) ?></div>
          </div>
        <?php endforeach; ?>
      </div>

      <form id="chatForm" class="composer">
        <textarea id="chatInput" placeholder="Message..." rows="1" required></textarea>
        <button type="submit" id="sendBtn">Send</button>
      </form>
      <p class="cost-note"><?= TOKENS_PER_MESSAGE ?> token per message</p>
    </main>
  </div>

  <script>
    window.CONV_ID = <?= (int)$convId ?>;
    window.CSRF = <?= json_encode(csrf_token()) ?>;
  </script>
  <script src="assets/chat.js"></script>
</body>
</html>
