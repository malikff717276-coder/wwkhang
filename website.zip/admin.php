<?php
require_once __DIR__ . '/auth.php';
$admin = require_admin();
$db = get_db();

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $targetId = (int)($_POST['user_id'] ?? 0);

    if ($action === 'topup' && $targetId) {
        $amount = (int)($_POST['amount'] ?? 0);
        if ($amount > 0) {
            adjust_tokens($targetId, $amount, 'admin_topup');
            $message = "Added $amount tokens.";
        }
    } elseif ($action === 'toggle_active' && $targetId) {
        $db->prepare('UPDATE users SET is_active = 1 - is_active WHERE id = ?')->execute([$targetId]);
        $message = 'Account status updated.';
    } elseif ($action === 'toggle_admin' && $targetId) {
        $db->prepare('UPDATE users SET is_admin = 1 - is_admin WHERE id = ?')->execute([$targetId]);
        $message = 'Admin status updated.';
    }
}

$users = $db->query('SELECT id, username, email, tokens, is_admin, is_active, created_at FROM users ORDER BY id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin — <?= htmlspecialchars(SITE_NAME) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="admin-page">
  <div class="admin-shell">
    <div class="admin-header">
      <h1>Admin — <?= htmlspecialchars(SITE_NAME) ?></h1>
      <a href="chat.php">&larr; Back to chat</a>
    </div>

    <?php if ($message): ?><div class="alert alert-ok"><?= htmlspecialchars($message) ?></div><?php endif; ?>

    <table class="admin-table">
      <thead>
        <tr><th>ID</th><th>Username</th><th>Email</th><th>Tokens</th><th>Admin</th><th>Active</th><th>Joined</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td><?= $u['id'] ?></td>
          <td><?= htmlspecialchars($u['username']) ?></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td><?= $u['tokens'] ?></td>
          <td><?= $u['is_admin'] ? 'Yes' : 'No' ?></td>
          <td><?= $u['is_active'] ? 'Yes' : 'No' ?></td>
          <td><?= htmlspecialchars($u['created_at']) ?></td>
          <td class="actions">
            <form method="post" class="inline-form">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
              <input type="hidden" name="action" value="topup">
              <input type="number" name="amount" min="1" value="10" class="amount-input">
              <button type="submit">Add tokens</button>
            </form>
            <form method="post" class="inline-form">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
              <input type="hidden" name="action" value="toggle_active">
              <button type="submit"><?= $u['is_active'] ? 'Disable' : 'Enable' ?></button>
            </form>
            <form method="post" class="inline-form">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
              <input type="hidden" name="action" value="toggle_admin">
              <button type="submit"><?= $u['is_admin'] ? 'Remove admin' : 'Make admin' ?></button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
