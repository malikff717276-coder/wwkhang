<?php
/**
 * ===========================================================
 *  CENTRAL CONFIG - change site name / settings ONLY here.
 *  Every page pulls from this file, so one edit applies
 *  everywhere (page titles, header, emails, etc).
 * ===========================================================
 */

// ---- Site identity (change this one line to rename the whole site) ----
define('SITE_NAME', 'YourSiteName');
define('SITE_TAGLINE', 'Ask anything. Get it solved.');

// ---- Database (InfinityFree gives you these in your control panel) ----
define('DB_HOST', 'sqlXXX.infinityfree.com');   // replace with your MySQL host
define('DB_NAME', 'epiz_XXXXXXXX_dbname');       // replace with your DB name
define('DB_USER', 'epiz_XXXXXXXX');              // replace with your DB user
define('DB_PASS', 'REPLACE_ME');                 // replace with your DB password

// ---- Cloudflare Main Worker (the AI backend you already built) ----
// This URL/secret is only ever used server-side (send.php), never sent to the browser.
//
// ⚠️ IMPORTANT: this must be your MAIN ROUTER WORKER's own URL — the one
// that runs main-worker.js and decides which model to call. It must NOT
// be one of the RECEIVERS.* URLs (qwen30b/coder32b/moondream/glm47) from
// inside that file — those are Account #2–#5, reached only by the router
// itself. Calling a receiver directly from the website skips the Gemini
// router, skips every other model, and skips the auth check below.
// Put your deployed Main Worker's *.workers.dev URL here:
define('WORKER_URL', 'https://curly-boat-1495.12345abcdefgh-404.workers.dev/');

// Must match the WEBSITE_SECRET you set on the Main Worker with:
//   wrangler secret put WEBSITE_SECRET
define('WORKER_SECRET', getenv('WORKER_SECRET') ?: 'REPLACE_AFTER_ROTATION');

// ---- Token economy ----
define('SIGNUP_BONUS_TOKENS', 20);   // free tokens new users get on signup
define('TOKENS_PER_MESSAGE', 1);     // tokens deducted per chat message sent

// ---- Session ----
define('SESSION_NAME', 'sitesess');

// ---- Error display (turn OFF in production) ----
define('DEBUG_MODE', false);

if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

date_default_timezone_set('Asia/Karachi');
