<?php
require_once __DIR__ . '/auth.php';

if (current_user()) {
    header('Location: chat.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = get_db()->prepare('SELECT id, password_hash, is_active FROM users WHERE username = ? OR email = ?');
    $stmt->execute([$username, $username]);
    $row = $stmt->fetch();

    if (!$row || !password_verify($password, $row['password_hash'])) {
        $error = 'Incorrect username/email or password.';
    } elseif (!$row['is_active']) {
        $error = 'This account has been disabled.';
    } else {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $row['id'];
        header('Location: chat.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Log in — <?= htmlspecialchars(SITE_NAME) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth-page">
  <div class="auth-card">
    <h1><?= htmlspecialchars(SITE_NAME) ?></h1>
    <p class="tagline"><?= htmlspecialchars(SITE_TAGLINE) ?></p>

    <?php if ($error): ?>
      <div class="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" class="auth-form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <label>Username or email
        <input type="text" name="username" required autofocus>
      </label>
      <label>Password
        <input type="password" name="password" required>
      </label>
      <button type="submit">Log in</button>
    </form>

    <p class="switch">New here? <a href="signup.php">Create an account</a></p>
  </div>
</body>
</html>
