<?php
require_once __DIR__ . '/auth.php';
header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => 'Not logged in.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
csrf_check_json($input['csrf'] ?? null);

$convId = (int)($input['conversation_id'] ?? 0);
$text   = trim($input['message'] ?? '');

if (!$convId || $text === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Missing message or conversation.']);
    exit;
}
if (mb_strlen($text) > 4000) {
    http_response_code(400);
    echo json_encode(['error' => 'Message too long (max 4000 characters).']);
    exit;
}

flood_check();

$db = get_db();

// Make sure this conversation belongs to the logged-in user
$stmt = $db->prepare('SELECT id FROM conversations WHERE id = ? AND user_id = ?');
$stmt->execute([$convId, $user['id']]);
if (!$stmt->fetch()) {
    http_response_code(403);
    echo json_encode(['error' => 'Invalid conversation.']);
    exit;
}

// Check token balance BEFORE calling the AI
$stmt = $db->prepare('SELECT tokens FROM users WHERE id = ? FOR UPDATE');
$db->beginTransaction();
$stmt->execute([$user['id']]);
$balance = (int)$stmt->fetchColumn();

if ($balance < TOKENS_PER_MESSAGE) {
    $db->rollBack();
    http_response_code(402);
    echo json_encode(['error' => 'Not enough tokens. Please top up.']);
    exit;
}

// Deduct up front to prevent double-spend on concurrent requests
$db->prepare('UPDATE users SET tokens = tokens - ? WHERE id = ?')->execute([TOKENS_PER_MESSAGE, $user['id']]);
$db->prepare('INSERT INTO token_log (user_id, change_amt, reason) VALUES (?, ?, ?)')
   ->execute([$user['id'], -TOKENS_PER_MESSAGE, 'chat_message']);
$db->commit();

// Save the user's message
$db->prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?, "user", ?)')
   ->execute([$convId, $text]);

// First message in a fresh conversation → use it as the sidebar title
$db->prepare("UPDATE conversations SET title = ? WHERE id = ? AND title = 'New chat'")
   ->execute([mb_substr($text, 0, 60), $convId]);

// The Main Worker keeps its own conversation memory in KV, keyed by
// "userId" (chat:<userId>) — it does NOT take a messages[] array, it
// takes one message at a time and looks up history itself. We scope
// that key to THIS website conversation (not just the account) so
// switching chats here also switches which memory thread the worker
// uses. Confirmed against main-worker.js: sanitizeUserId() allows
// underscores, so "_conv{id}" passes through untouched.
$workerUserId = $user['id'] . '_conv' . $convId;

// Call your Main Worker (Cloudflare)
$ch = curl_init(WORKER_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . WORKER_SECRET,
    ],
    CURLOPT_POSTFIELDS => json_encode([
        'userId'      => $workerUserId,
        'message'     => $text,
        'attachments' => [],
    ]),
    CURLOPT_TIMEOUT => 60,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr || $httpCode !== 200) {
    // Refund the token since the AI call failed
    adjust_tokens($user['id'], TOKENS_PER_MESSAGE, 'refund_failed_call');
    http_response_code(502);
    echo json_encode(['error' => 'AI service is unavailable right now. Your token was refunded.']);
    exit;
}

$data = json_decode($response, true);

if (empty($data['success'])) {
    // Worker returns { success:false, error, message } on failure
    // (e.g. bad auth, missing GEMINI_API_KEY, downstream account down)
    adjust_tokens($user['id'], TOKENS_PER_MESSAGE, 'refund_failed_call');
    http_response_code(502);
    echo json_encode(['error' => 'AI service returned an error. Your token was refunded.']);
    exit;
}

// Confirmed field from main-worker.js: { success, userId, response, routing, model }
$aiReply = $data['response'] ?? null;

if (!$aiReply) {
    adjust_tokens($user['id'], TOKENS_PER_MESSAGE, 'refund_failed_call');
    http_response_code(502);
    echo json_encode(['error' => 'AI service returned an empty response. Your token was refunded.']);
    exit;
}

$db->prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?, "assistant", ?)')
   ->execute([$convId, $aiReply]);

$stmt = $db->prepare('SELECT tokens FROM users WHERE id = ?');
$stmt->execute([$user['id']]);
$newBalance = (int)$stmt->fetchColumn();

echo json_encode([
    'reply' => $aiReply,
    'tokens' => $newBalance,
]);
